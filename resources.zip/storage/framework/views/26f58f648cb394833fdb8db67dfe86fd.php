<?php $__env->startSection('main-content'); ?>
    <!-- Page Heading -->
    <h1 class="h3 mb-3 text-gray-800"><?php echo e(__('Pengaturan')); ?></h1>

    <!-- Main Content goes here -->
    <div class="card shadow">
        <div class="card-header">
            <ul class="nav nav-tabs card-header-tabs">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Nav::isRoute('admin-wilayah.data.anggota-jemaat')); ?>" aria-current="true" href="<?php echo e(route('admin-wilayah.data.anggota-jemaat')); ?>">DATA JEMAAT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(Nav::isRoute('admin-wilayah.data.anggota-jemaat-keluarga')); ?>" aria-current="true" href="<?php echo e(route('admin-wilayah.data.anggota-jemaat-keluarga')); ?>">KELUARGA JEMAAT</a>
                </li>
            </ul>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- End of Main Content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('notif'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin-wilayah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\College\Semester7\SIJ-GKJM\resources\views/layouts/admin-wilayah-main-data.blade.php ENDPATH**/ ?>