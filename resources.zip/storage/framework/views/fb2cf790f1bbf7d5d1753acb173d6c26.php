<?php $__env->startSection('main-content'); ?>

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?php echo e(__('Dashboard Ulangtahun')); ?></h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success border-left-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success border-left-success" role="alert">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <form id="form" method="GET" action="<?php echo e(route('admin.birthdayDash')); ?>" class="container mt-4">
        <div class="card p-3 shadow-sm">
            <div class="form-row align-items-center">
                <div class="col-auto">
                    <label for="start_date" class="mr-2 font-weight-bold">Tanggal Awal:</label>
                    <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                </div>
                <div class="col-auto">
                    <label for="end_date" class="mr-2 font-weight-bold">Tanggal Akhir:</label>
                    <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                </div>
                <div class="col-auto mt-2">
                    <button type="submit" class="btn btn-primary">Cari</button>
                    <button type="reset" class="btn btn-danger" onclick="resetDate()">Reset</button>
                </div>
            </div>
        </div>
    </form>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8">
                <h4 class="mt-4">Ulangtahun Jemaat</h4>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <button class="btn btn-secondary" onclick="resetTable()">Show All Wilayah</button>
                        <canvas id="chartJemaatPerWilayah" style="width:100%; height:300px;"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <h4 class="mt-4">Jemaat Ulangtahun</h4>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <?php if($pagination->isNotEmpty()): ?>
                        <table class="table table-striped table-bordered" id='jemaatTable'>
                            <thead>
                                <tr>
                                    <th>Nama</th>
                                    <th>Tanggal Lahir</th>
                                    <th>Wilayah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pagination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->nama_jemaat ?? 'N/A'); ?></td>
                                        <td><?php echo e($data->tanggal_lahir ?? 'N/A'); ?></td>
                                        <td><?php echo e($data->wil ?? 'Tidak Ada Wilayah'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">
                            <?php echo e($pagination->links('admin.custom-pagination')); ?>

                        </div>
                        <?php else: ?>
                            <p class="text-danger">Data tidak ditemukan untuk rentang tanggal tersebut.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-8">
                <h4 class="mt-4">Ulangtahun Pernikahan</h4>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <button class="btn btn-secondary" onclick="resetTable()">Show All Wilayah</button>
                        <canvas id="chartMarried" style="width:100%; height:300px;"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <h4 class="mt-4"> Ulangtahun Pernikahan</h4>
                <div class="card shadow-sm">
                    <div class="card-body">
                        <?php if($paginationMarried->isNotEmpty()): ?>
                        <table class="table table-striped table-bordered" id='marriedTable'>
                            <thead>
                                <tr>
                                    <th>Nama Pengantin Pria</th>
                                    <th>Nama Pengantin Wanita</th>
                                    <th>Tanggal Nikah</th>
                                    <th>Wilayah</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $paginationMarried; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data->pengantin_pria ?? 'N/A'); ?></td>
                                        <td><?php echo e($data->pengantin_wanita ?? 'N/A'); ?></td>
                                        <td><?php echo e($data->tanggal_nikah ?? 'N/A'); ?></td>
                                        <td class="wilayah"><?php echo e($data->nama_wilayah); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <div class="d-flex justify-content-center">
                            <?php echo e($pagination->links('admin.custom-pagination')); ?>

                        </div>
                        <?php else: ?>
                            <p class="text-danger">Data tidak ditemukan untuk rentang tanggal tersebut.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    function filterTableByWilayah(wilayah) {
        const tableRows = document.querySelectorAll('#jemaatTable tbody tr');

        tableRows.forEach(row => {
            const wilayahCell = row.querySelector('td:nth-child(3)');
            if (wilayahCell.textContent.trim() === wilayah) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
    function MarriedTableByWilayah(selectedWilayah) {
        const rows = document.querySelectorAll('#marriedTable tbody tr');

        rows.forEach(row => {
            const wilayahCell = row.querySelector('.wilayah');
            if (wilayahCell) {
                const wilayah = wilayahCell.textContent;
                if (wilayah === selectedWilayah) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        });
    }

    function resetTable() {
        const jemaatRows = document.querySelectorAll('#jemaatTable tbody tr');
        const marriedRows = document.querySelectorAll('#marriedTable tbody tr');
        jemaatRows.forEach(row => {
            row.style.display = '';
        });
        marriedRows.forEach(row => {
            row.style.display = '';
        });
    }

    const chart1 = document.getElementById('chartJemaatPerWilayah').getContext('2d');
    const jemaatChart = new Chart(chart1, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($labelWilayah, 15, 512) ?>,
            datasets: [{
                label: 'Jumlah Jemaat',
                data: <?php echo json_encode($dataCount, 15, 512) ?>,
                backgroundColor: 'rgba(0, 53, 220, 0.7)',
                borderColor: 'rgba(0, 53, 220, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Jumlah'
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Wilayah'
                    }
                }
            },
            onClick: (event, elements) => {
                if (elements.length > 0) {
                    const index = elements[0].index;
                    const wilayahClicked = jemaatChart.data.labels[index];
                    filterTableByWilayah(wilayahClicked);
                }
            }
        }
    });
    var chart2 = document.getElementById('chartMarried').getContext('2d');
    var chartMarried = new Chart(chart2, {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($wilayahNames, 15, 512) ?>, // X-axis labels
            datasets: [{
                label: 'Total Weddings',
                data: <?php echo json_encode($weddingCounts, 15, 512) ?>, // Y-axis data
                backgroundColor: 'rgba(75, 192, 192, 0.8)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            },
            onClick: function(evt, elements) {
                if (elements.length > 0) {
                    const clickedIndex = elements[0].index;
                    const selectedWilayah = <?php echo json_encode($wilayahNames, 15, 512) ?>[clickedIndex];
                    console.log("Bar clicked: ", selectedWilayah);
                    MarriedTableByWilayah(selectedWilayah);
                }
            }
        }
    });
    function resetDate() {
        document.getElementById('start_date').value = '';
        document.getElementById('end_date').value = '';
        document.getElementById('form').submit();  // Submit the form to apply the reset
}

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\College\Semester7\SIJ-GKJM\resources\views/admin/birthdayDash.blade.php ENDPATH**/ ?>