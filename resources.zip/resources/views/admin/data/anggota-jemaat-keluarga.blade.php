@extends('layouts.admin-main-data')

@section('title', 'Anggota Jemaat Keluarga')

@push('css')
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="{{ asset('css/bootstrap-table.css') }}">
    <link rel="stylesheet" href="{{ asset('css/custom-admin.css') }}">
    <style>
        .btn-keluarga {
            color: white;
        }
    </style>
@endpush

@section('content')
    <div class="card-body">
        <a href="" class="btn btn-success tambah-keluarga">Tambah Keluarga</a>
        <div id="toolbar" class="select">
            <select class="form-control">
                <option value="">Export (Hanya yang Ditampilkan)</option>
                <option value="all">Export (Semua)</option>
                <option value="selected">Export (Yang Dipilih)</option>
            </select>
        </div>
        <table id="table" data-show-export="true" data-pagination="true" data-click-to-select="true"
            data-toolbar="#toolbar" data-search="true" data-show-toggle="true" data-show-columns="true"
            data-ajax="ApiGetKeluarga">
        </table>
    </div>
@endsection

@push('js')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="{{ asset('js/bootstrap-table.js') }}"></script>
    <script src="{{ asset('js/table-export/jsPDF/polyfills.umd.min.js') }}"></script>
    <script src="{{ asset('js/bootstrap-table-export.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/tableexport.jquery.plugin@1.29.0/tableExport.min.js"></script>
    <script src="{{ asset('js/table-export/jsPDF/jspdf.umd.min.js') }}"></script>
    <script src="{{ asset('js/table-export/FileSaver/FileSaver.min.js') }}"></script>
    <script src="{{ asset('js/table-export/js-xlsx/xlsx.core.min.js') }}"></script>
    <script src="{{ asset('js/table-export/html2canvas/html2canvas.min.js') }}"></script>
    <script>
        var $table = $('#table');
        $(document).ready(function() {
            // Initialize bootstrap table
            $table.bootstrapTable({
                columns: [{
                    field: 'id_keluarga',
                    title: 'ID Keluarga',
                    align: 'center'
                }, {
                    field: 'kepala_keluarga',
                    title: 'Nama Kepala Keluarga',
                    align: 'center'
                },{
                    field: 'nama_wilayah',
                    title: 'Wilayah',
                    align: 'center'
                },{
                    field: 'edit_kepala_keluarga',
                    title: 'Edit Kepala Keluarga',
                    formatter: function(value, row, index) {
                        return `<button class="btn btn-warning btn-edi" type="button" data-id="${row.id_keluarga}">Edit</button>`;
                    },
                    align: 'center'
                }, {
                    field: 'edit_keluarga',
                    title: 'Edit Anggota Keluarga',
                    formatter: function(value, row, index) {
                        return `<button class="btn btn-warning btn-edi" type="button" data-id="${row.id_keluarga}">Edit</button>`;
                    },
                    align: 'center'
                }, {
                    field: 'edit',
                    title: 'Lihat Keluarga',
                    formatter: function(value, row, index) {
                        return `
                        <button class="btn btn-success btn-keluarga" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-${row.id_keluarga}" aria-expanded="false" aria-controls="collapse-${row.id_keluarga}" data-id="${row.id_keluarga}">
                            Lihat Keluarga
                        </button>

                        <div class="collapse" id="collapse-${row.id_keluarga}">
                            <div class="card card-body mt-2">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID Jemaat</th>
                                            <th>Nama Jemaat</th>
                                            <th>Tanggal Lahir</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${row.jemaat.map(j => `
                                                <tr>
                                                    <td>${j.id_jemaat}</td>
                                                    <td>${j.nama_jemaat}</td>
                                                    <td>${j.tanggal_lahir}</td>
                                                </tr>
                                            `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        </div>`;
                    },
                    align: 'center'
                }, {
                    field: 'delete',
                    title: 'Delete',
                    formatter: function(value, row, index) {
                        return `<button class="btn btn-danger btn-delete" data-id="${row.id_keluarga}">Delete</button>`;
                    },
                    align: 'center'
                }],
                exportOptions: {
                    ignoreColumn: [4, 5]
                }
            });

            // Handle perubahan toolbar select
            $('#toolbar').find('select').change(function() {
                var exportDataType = $(this).val();
                $table.bootstrapTable('refreshOptions', {
                    exportDataType: exportDataType,
                    exportTypes: ['excel', 'pdf'],
                    columns: [{
                        field: 'state',
                        checkbox: true,
                        visible: exportDataType === 'selected'
                    }, {
                        field: 'id_keluarga',
                        title: 'ID Keluarga',
                        align: 'center'
                    }, {
                        field: 'kepala_keluarga',
                        title: 'Nama Kepala Keluarga',
                        align: 'center'
                    },{
                        field: 'nama_wilayah',
                        title: 'Wilayah',
                        align: 'center'
                    }, {
                        field: 'Keluarga',
                        title: 'Lihat Keluarga',
                        formatter: function(value, row, index) {
                            return `
                                <button class="btn btn-success btn-keluarga" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-${row.id_keluarga}" aria-expanded="false" aria-controls="collapse-${row.id_keluarga}" data-id="${row.id_keluarga}">
                                    Lihat Keluarga
                                </button>

                                <div class="collapse" id="collapse-${row.id_keluarga}">
                                    <div class="card card-body mt-2">
                                        <table class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>ID Jemaat</th>
                                                    <th>Nama Anggota</th>
                                                    <th>Keterangan Status</th>
                                                </tr>
                                            </thead>
                                            <tbody id="anggota-keluarga-body-${row.id_keluarga}">
                                                <!-- Data anggota keluarga akan dimuat di sini -->
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            `;
                        },
                        align: 'center'
                    }, {
                        field: 'edit_kepala_keluarga',
                        title: 'Edit Kepala Keluarga',
                        formatter: function(value, row, index) {
                            return `<button class="btn btn-warning btn-edi" type="button" data-id="${row.id_keluarga}">Edit</button>`;
                        },
                        align: 'center'
                    }, {
                        field: 'edit_keluarga',
                        title: 'Edit Anggota Keluarga',
                        formatter: function(value, row, index) {
                            return `<button class="btn btn-warning btn-edi" type="button" data-id="${row.id_keluarga}">Edit</button>`;
                        },
                        align: 'center'
                    }, {
                        field: 'delete',
                        title: 'Delete',
                        formatter: function(value, row, index) {
                            return `<button class="btn btn-danger btn-delete" data-id="${row.id_keluarga}">Delete</button>`;
                        },
                        align: 'center'
                    }],
                    exportOptions: {
                        ignoreColumn: [4, 5]
                    }
                });
            }).trigger('change');

            // Event listener untuk tombol keluarga
            $(document).on('click', '.btn-keluarga', function() {
            const idKeluarga = $(this).data('id');
            const tbody = $(`#anggota-keluarga-body-${idKeluarga}`);
            if (tbody.children().length > 0) return;

            $.ajax({
                url: "{{ route('api.get.anggotakeluarga') }}",
                method: 'POST',
                data: { id_keluarga: idKeluarga },
                success: function(anggotaKeluarga) {
                    anggotaKeluarga.forEach(anggota => {
                        tbody.append(`
                            <tr>
                                <td>${anggota.id_jemaat || 'N/A'}</td>
                                <td>${anggota.nama_anggota || 'N/A'}</td>
                                <td>${anggota.keterangan_status || 'N/A'}</td>
                            </tr>
                        `);
                    });
                },
                error: function(xhr, status, error) {
                    console.error("Error fetching anggota keluarga:", error);
                    tbody.append(`
                        <tr>
                            <td colspan="3" class="text-center">Gagal memuat data anggota keluarga</td>
                        </tr>
                    `);
                }
            });
        });

            // Event listener untuk tombol tambah wilayah
            $('.tambah-anggota-keluarga').on('click', function() {
                event.preventDefault();
                Swal.fire({
                    title: 'Tambah Keluarga Baru',
                    html: `
                        <form id="addWilayahForm">
                            <div class="form-group">
                                <label for="idWilayah">ID Wilayah</label>
                                <input type="text" id="idWilayah" class="form-control" placeholder="Masukkan ID Wilayah">
                            </div>
                            <div class="form-group mb-0">
                                <label for="namaWilayah">Nama Wilayah</label>
                                <input type="text" id="namaWilayah" class="form-control" placeholder="Masukkan Nama Wilayah">
                            </div>
                        </form>
                    `,
                    showCancelButton: true,
                    confirmButtonText: 'Simpan',
                    cancelButtonText: 'Batal',
                    preConfirm: () => {
                        const idWilayah = $('#idWilayah').val();
                        const namaWilayah = $('#namaWilayah').val();

                        // Validasi input
                        if (!idWilayah || !namaWilayah) {
                            Swal.showValidationMessage(
                                'ID Wilayah dan Nama Wilayah harus diisi!');
                            return false;
                        }

                        return {
                            idWilayah: idWilayah,
                            namaWilayah: namaWilayah
                        };
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Ambil data dari result.value
                        const {
                            idWilayah,
                            namaWilayah
                        } = result.value;

                        // AJAX request untuk menambah wilayah
                        $.ajax({
                            url: '/add-wilayah',
                            type: 'POST',
                            data: {
                                _token: '{{ csrf_token() }}',
                                idWilayah: idWilayah,
                                namaWilayah: namaWilayah
                            },
                            success: function(response) {
                                alert.fire({
                                    icon: 'success',
                                    title: 'Data wilayah berhasil ditambahkan!'
                                });
                                $table.bootstrapTable('refresh');
                            },
                            error: function(xhr, status, error) {
                                alert.fire({
                                    icon: 'success',
                                    title: 'Data wilayah gagal ditambahkan!'
                                });
                            }
                        });
                    }
                });
            });

            // Event listener untuk tombol edit
            $(document).on('click', '.btn-edit', function() {
                event.preventDefault();
                var id = $(this).data('id');
                var name = $(this).data('name');

                Swal.fire({
                    title: 'Edit Keluarga',
                    html: `
                        <form id="editForm">
                            <div class="form-group">
                                <label for="idWilayah">ID Wilayah</label>
                                <input type="text" id="idWilayah" class="form-control" value="${id}" disabled>
                            </div>
                            <div class="form-group mb-0">
                                <label for="nameItem">Nama Wilayah</label>
                                <input type="text" id="nameItem" class="form-control" value="${name}">
                            </div>
                        </form>
                    `,
                    showCancelButton: true,
                    confirmButtonText: 'Save',
                    cancelButtonText: 'Cancel',
                    preConfirm: () => {
                        const newName = $('#nameItem').val();
                        if (!newName) {
                            Swal.showValidationMessage('Nama item tidak boleh kosong!');
                            return false;
                        }
                        return {
                            newName: newName
                        };
                    }
                }).then((result) => {
                    if (result.isConfirmed) {
                        const newName = result.value.newName;

                        // Contoh: Update menggunakan AJAX
                        $.ajax({
                            url: `/edit/${id}`,
                            type: 'POST',
                            data: {
                                _token: '{{ csrf_token() }}',
                                id: id,
                                name: newName
                            },
                            success: function(response) {
                                alert.fire({
                                    icon: 'success',
                                    title: 'Data wilayah berhasil diubah!'
                                });
                                $table.bootstrapTable('refresh');
                            },
                            error: function(xhr, status, error) {
                                alert.fire({
                                    icon: 'danger',
                                    title: 'Data wilayah gagal diupdate!'
                                });
                            }
                        });
                    }
                });
            });
        });

        $(document).on('click', '.btn-delete', function() {
            event.preventDefault();
            var id = $(this).data('id');

            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: `/delete/${id}`,
                        type: 'DELETE',
                        success: function(response) {
                            alert.fire({
                                icon: 'success',
                                title: 'Data wilayah berhasil dihapus!'
                            });
                            $table.bootstrapTable('refresh');
                        },
                        error: function(xhr, status, error) {
                            alert.fire({
                                icon: 'error',
                                title: 'Data wilayah gagal dihapus!'
                            });
                        }
                    });
                }
            });
        });

        function ApiGetKeluarga(params) {
            $.ajax({
                type: "POST",
                url: "{{ route('api.get.keluarga') }}",
                data: {
                    _token: '{{ csrf_token() }}'
                },
                dataType: "json",
                success: function(data) {
                    params.success(data);
                },
                error: function(xhr, status, error) {
                    console.error("Error: " + error);
                    console.error("Status: " + status);
                    console.dir(xhr);
                }
            });
        }
    </script>
@endpush
